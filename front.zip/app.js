App({
  globalData: {
    userInfo: null,
    isAdmin: false,
    themeConfig: null,
    themeColor: '#1AAD19'
  },

  onLaunch() {
    // 从本地存储恢复登录状态
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.globalData.userInfo = userInfo;
      this.globalData.isAdmin = userInfo.isAdmin || false;
    }
    
    // 从本地存储恢复主题配置
    const themeConfig = wx.getStorageSync('themeConfig');
    if (themeConfig) {
      this.globalData.themeConfig = themeConfig;
      this.globalData.themeColor = themeConfig.primaryColor || '#1AAD19';
    }
  },

  /**
   * 获取当前主题色
   */
  getThemeColor() {
    return this.globalData.themeColor || '#1AAD19';
  },

  /**
   * 应用主题配置
   * @param {Object} config - 主题配置对象
   */
  applyThemeConfig(config) {
    if (!config) return;

    // 更新全局数据
    this.globalData.themeConfig = config;
    this.globalData.themeColor = config.primaryColor || '#1AAD19';

    // 应用导航栏颜色
    if (config.navigationBarBackgroundColor) {
      wx.setNavigationBarColor({
        frontColor: '#ffffff',
        backgroundColor: config.navigationBarBackgroundColor,
        animation: {
          duration: 300,
          timingFunc: 'easeInOut'
        }
      });
    }

    // 应用 tabBar 颜色（如果配置了）
    if (config.tabBarSelectedColor) {
      wx.setTabBarStyle({
        selectedColor: config.tabBarSelectedColor
      });
    }
  },

  /**
   * 开发调试：快速切换管理员模式
   * 在控制台调用 getApp().setAdminMode(true) 即可
   */
  setAdminMode(isAdmin) {
    const userInfo = this.globalData.userInfo;
    if (userInfo) {
      userInfo.isAdmin = isAdmin;
      this.globalData.isAdmin = isAdmin;
      wx.setStorageSync('userInfo', userInfo);
    }
  }
});
